from django.contrib import admin
from import_export.admin import ImportExportModelAdmin
from .models import Hlearning, HL_branche, Course,Bg_pic

@admin.register(Hlearning)
class HlearningAdmin(ImportExportModelAdmin):
	list_display = ('school_name',
					'religion',
					'location',
					'school_contact',
					'category',
					'course',
					'study',
					'recognition',
					'institute_type',
					'email',
					'website',
					'description',
					'logo',
					)


admin.site.register(Course)
# admin.site.register(Hlearning)
admin.site.register(HL_branche)
admin.site.register(Bg_pic)