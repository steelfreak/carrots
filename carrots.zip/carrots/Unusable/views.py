from django.shortcuts import render
from .models import Hlearning,HL_branche,Bg_pic
from django.views.generic import ( 
	ListView, 
	DetailView, 
	UpdateView,
	CreateView,
	DeleteView
)
from django.urls import reverse_lazy
import pandas as pd
import os
from django.http import JsonResponse
from django.conf import settings


def search_inst(request):
	if request.method == 'POST':
		searched = request.POST['searched']
		schools = Hlearning.objects.filter(school_name__contains=searched)

		return render(request, 'institutions/search_inst.html', 
			{'searched':searched, 'schools':schools})
	else:
		return render(request, 'institutions/search_inst.html', {})

def myoutexcel(request):
	objs = Hlearning.objects.all()
	data = []
	for obj in objs:
		data.append({
			"school_name"	: obj.school_name,
			"school_contact": obj.school_contact,
			"category"		: obj.category,
			"study"			: obj.study,
			"recognition"	: obj.recognition,
			"institute_type": obj.institute_type,
			"email"			: obj.email,
			"website"		: obj.website			
			})
	pd.DataFrame(data).to_excel('output.xlsx')
	return JsonResponse({
			'status' : 200
		})

class IndexView(ListView):
	model = Hlearning
	template_name='institutions/index.html'
	context_object_name='index'


class IndexViewAdmin(ListView):
	model = Hlearning
	template_name='institutions/admin.html'
	context_object_name='index'


class SingleView(DetailView):
	model=Hlearning
	template_name='institutions/single.html'
	context_object_name='post'


class AddView(CreateView):
	model=Hlearning
	template_name='institutions/add.html'
	fields='__all__'
	success_url=reverse_lazy('index')




class AddView2(CreateView):
	model=HL_branche
	template_name='institutions/add.html'
	fields='__all__'
	success_url=reverse_lazy('index')


class AddView3(CreateView):
	model=Bg_pic
	template_name='institutions/add.html'
	fields='__all__'
	success_url=reverse_lazy('index')


class EditView(UpdateView):
	model=Hlearning
	template_name='institutions/edit.html'
	fields='__all__'
	pk_url_kwarg='pk'
	success_url=reverse_lazy('index')



class EditView2(UpdateView):
	model=HL_branche
	template_name='institutions/edit.html'
	fields='__all__'
	pk_url_kwarg='pk'
	success_url=reverse_lazy('index')


class EditView3(UpdateView):
	model=Bg_pic
	template_name='institutions/edit.html'
	fields='__all__'
	pk_url_kwarg='pk'
	success_url=reverse_lazy('index')


# class Delete(DeleteView):
# 	model=Hlearning
# 	# success_url=reverse_lazy('index')
# 	# template_name='institution/inde/confirm-delete.html'


# class Delete(DeleteView):
# 	model=Hlearning
# 	template_name='institution/inde/confirm-delete.html'
# 	pk_url_kwarg='pk'
# 	success_url=reverse_lazy('institution/inde:posts')


