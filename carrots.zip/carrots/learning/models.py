from django.db import models
from django.urls import reverse
from django.utils import timezone
from PIL import Image




class Hlearning(models.Model):
	CATEGORY = (
		('Univesity','Univesity'),
		('Technical / Vocational','Technical / Vocational'),
		('College','College'),
		('HighSchool','HighSchool'),
		('Primary','Primary'),
		('Nursery','Nursery')
		)
	STUDY = (
		('PHD','PHD'),
		('Masters','Masters'),
		('Degree','Degree'),
		('Deploma','Deploma'),
		('Certificate','Certificate'),
		)
	RELIGION = (
		('SDA','SDA'),
		('Catholics','Catholics'),
		('Islam','Islam'),
		('Born Again','Born Again'),
		('Pentacostal','Pentacostal'),
		('Hindu','Hindu'),
		('Circular','Circular')
		)
	RECOGNITION = (
		('Accredited','Accredited'),
		('Not Accredited','Not Accredited')
		)
	TYPE = (
		('Public','Public'),
		('Private','Private')
		)

	school_name=models.CharField(max_length=200)
	religion=models.CharField(max_length=200, null=True, choices=RELIGION)
	school_contact=models.CharField(max_length=500)
	category=models.CharField(max_length=200, null=True, choices=CATEGORY)
	course=models.CharField(max_length=500)
	study=models.CharField(max_length=200, null=True, choices=STUDY)
	recognition=models.CharField(max_length=200, null=True, choices=RECOGNITION)
	institute_type=models.CharField(max_length=200, null=True, choices=TYPE)
	email=models.EmailField(default='example@example.edu')
	website=models.URLField(default='www')
	description=models.CharField(max_length=200)	
	date_posted=models.DateTimeField(default=timezone.now)

	

	def __str__(self):
		return self.school_name


class HL_branche(models.Model): #Higher Lerning Branches	
	name=models.ForeignKey(Hlearning, null=True, on_delete=models.SET_NULL)
	school_address=models.CharField(max_length=500)
	email=models.CharField(max_length=200)
	tel=models.IntegerField()
	

	def __str__(self):
		return self.email


class Bg_pic(models.Model): #Back Ground Picture
	name=models.CharField(max_length=200)
	logo=models.ImageField(default='default.jpg', upload_to='mypics')
	# bg=models.ImageField(default='default.jpg', upload_to='background_pic')
	
	def save(self, *args, **kwargs):
		super().save(*args, **kwargs)
		img=Image.open(self.logo.path)

	def __str__(self):
		return self.name