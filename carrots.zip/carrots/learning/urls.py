from django.urls import path
from .import views


urlpatterns = [
    path('', views.IndexView.as_view(),name='index'),
    # path('', views.IndexViewPic.as_view(),name='index1'),
    path('main/', views.IndexViewAdmin.as_view(),name='index_Admin'),
    path('full/<int:pk>/', views.SingleView.as_view(),name='single'),
    path('add/', views.AddView.as_view(),name='add'),
    path('add2/', views.AddView2.as_view(),name='add_branch'),
    path('add3/', views.AddView3.as_view(),name='addbg'),
    path('edit/<int:pk>/', views.EditView.as_view(),name='edit'),
    path('edit2/<int:pk>/', views.EditView2.as_view(),name='edit_branch'),
    path('edit3/<int:pk>/', views.EditView3.as_view(),name='editbg'),
    path('search', views.search_inst,name='search-inst'),
    # path('<int:pk>/delete/', views.DeleteView.as_view(),name='delete'),
    # # path('<int:pk>/delete/', views.DeleteView.as_view(),name='delete'),
    path('outexcel', views.myoutexcel,name='excelout'),
   
    
]