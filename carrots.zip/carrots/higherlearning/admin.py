from django.contrib import admin
from import_export.admin import ImportExportModelAdmin
from .models import Institute, Hschool, Pschool

@admin.register(Institute)
class InstituteAdmin(ImportExportModelAdmin):
	list_display = ('sch_name',
					'religion',
					'status',
					'course_type',
					'recognition',
					'institute_type',
					'email',
					'contact',
					'website',
					'description',
					'date_posted',
					'logo'
					)

@admin.register(Hschool)
class InstituteAdmin(ImportExportModelAdmin):
	list_display = ('sch_name',
					'religion',
					'recognition',
					'institute_type',
					'email',
					'contact',
					'website',
					'description',
					'date_posted',
					'logo'
					)


@admin.register(Pschool)
class InstituteAdmin(ImportExportModelAdmin):
	list_display = ('sch_name',
					'religion',
					'region',
					'district',
					'county',
					'subcounty',
					'parish',
					'institute_type',
					'email',
					'contact',
					'website',
					'description',
					'date_posted',
					'logo'
					)



