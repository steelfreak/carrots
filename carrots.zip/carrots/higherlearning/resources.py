from import_export import resources
from .models import Institute

class InstituteResource(resources.ModelResource):
	class meta:
		model = Institute