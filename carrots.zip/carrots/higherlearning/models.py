from django.db import models
from django.urls import reverse
from django.utils import timezone
from PIL import Image




class Institute(models.Model):	
	STATUS = (
		('University','University'),
		('Tertiary','Tertiary'),
		('Collage','Collage'),
		)
	
	RECOGNITION = (
		('Accredited','Accredited'),
		('Not Accredited','Not Accredited')
		)
	TYPE = (
		('Government','Government'),
		('Private','Private')
		)

	sch_name=models.CharField(max_length=200)
	religion=models.CharField(max_length=200, default='Christian')
	status=models.CharField(max_length=200, null=True, choices=STATUS)	
	course_type=models.CharField(max_length=500, default='Certificate')
	recognition=models.CharField(max_length=200, null=True, choices=RECOGNITION)
	institute_type=models.CharField(max_length=200, null=True, choices=TYPE)
	email=models.EmailField(default='institute@domain.edu')
	contact=models.CharField(max_length=500)
	website=models.URLField(default='www.')
	description=models.CharField(max_length=200)	
	date_posted=models.DateTimeField(default=timezone.now)
	logo=models.ImageField(default='default.jpg', upload_to='institute')
	
	# This should be turn off while importing New Data
	def save(self, *args, **kwargs):
		super().save(*args, **kwargs)
		img=Image.open(self.logo.path)

		if img.height > 300 or img.weight >300:
			output_size = (300,300)
			img.thumbnail(output_size)
			img.save(self.logo.path)	

	def __str__(self):
		return self.sch_name


class Hschool(models.Model):			
	RECOGNITION = (
		('Accredited','Accredited'),
		('Not Accredited','Not Accredited')
		)
	TYPE = (
		('Government','Government'),
		('Private','Private')
		)

	sch_name=models.CharField(max_length=200)
	religion=models.CharField(max_length=200, default='N/A')
	recognition=models.CharField(max_length=200, null=True, choices=RECOGNITION)
	institute_type=models.CharField(max_length=200, null=True, choices=TYPE)
	email=models.EmailField(default='institute@domain.edu')
	contact=models.CharField(max_length=500, default='N/A')
	website=models.URLField(default='www.')
	description=models.CharField(max_length=200, default='N/A')	
	date_posted=models.DateTimeField(default=timezone.now)
	logo=models.ImageField(default='default.jpg', upload_to='highschool')
	
	# This should be turn off while importing New Data
	def save(self, *args, **kwargs):
		super().save(*args, **kwargs)
		img=Image.open(self.logo.path)

		if img.height > 300 or img.weight >300:
			output_size = (300,300)
			img.thumbnail(output_size)
			img.save(self.logo.path)	

	def __str__(self):
		return self.sch_name


class Pschool(models.Model):
	TYPE = (
		('Government','Government'),
		('Private','Private')
		)

	sch_name=models.CharField(max_length=200)
	religion=models.CharField(max_length=200, default='N/A')
	region=models.CharField(max_length=200, default='N/A')
	district=models.CharField(max_length=200, default='N/A')
	county=models.CharField(max_length=200, default='N/A')
	subcounty=models.CharField(max_length=200, default='N/A')
	parish=models.CharField(max_length=200, default='N/A')
	institute_type=models.CharField(max_length=200, null=True, choices=TYPE)
	email=models.EmailField(default='institute@domain.edu')
	contact=models.CharField(max_length=500, default='N/A')
	website=models.URLField(default='www.')
	description=models.CharField(max_length=200, default='N/A')	
	date_posted=models.DateTimeField(default=timezone.now)
	logo=models.ImageField(default='default.jpg', upload_to='primaryschool')
	
	# This should be turn off while importing New Data
	def save(self, *args, **kwargs):
		super().save(*args, **kwargs)
		img=Image.open(self.logo.path)

		if img.height > 300 or img.weight >300:
			output_size = (300,300)
			img.thumbnail(output_size)
			img.save(self.logo.path)	

	def __str__(self):
		return self.sch_name


